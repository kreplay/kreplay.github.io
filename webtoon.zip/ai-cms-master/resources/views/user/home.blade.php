@extends('layouts.web.base')

@section('title')
@parent Home
@endsection

@section('content')
Home User
@endsection
