@extends('admin.base')

@section('title')
Manga Views
@endsection

@section('breadcrumb')

@endsection

@section('page-content')
a
@endsection
