@extends('admin.base')

@section('title')
Page Views
@endsection

@section('breadcrumb')

@endsection

@section('page-content')

@endsection
