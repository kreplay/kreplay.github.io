@extends('admin.base')

@section('title')
@parent Comments
@endsection

@section('breadcrumb')
<li><a>Home</a></li>
<li><a>Comments</a></li>
@endsection

@section('page-content')

@endsection