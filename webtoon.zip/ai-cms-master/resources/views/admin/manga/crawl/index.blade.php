@extends('admin.base')

@section('breadcrumb')
<li><a>Manga</a></li>
<li><a class="link-effect">Crawl Manga</a></li>
@endsection

@section('page-content')
@include('errors.notready')
@endsection
