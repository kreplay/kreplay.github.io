<vue-modal data-name="modal-form" :data-class="['modal-dialog-slideup', 'modal-lg']" :is-fade="true">
	<vue-modal-head>Add Staff Pick</vue-modal-head>
	<vue-modal-body></vue-modal-body>
	<vue-modal-footer slot="footer"></vue-modal-footer>
</vue-modal>
