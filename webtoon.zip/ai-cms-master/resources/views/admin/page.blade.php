@extends('admin.base')

@section('title')
@parent Page List
@endsection

@section('breadcrumb')
<li><a>Home</a></li>
<li><a>Page</a></li>
@endsection

@section('page-content')

@endsection