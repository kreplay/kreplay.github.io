@extends('admin.base')

@section('title')
Setting Widget
@endsection

@section('breadcrumb')
<li><a>Settings</a></li>
<li><a class="link-effect">Widget</a></li>
@endsection

@section('page-content')

@endsection
