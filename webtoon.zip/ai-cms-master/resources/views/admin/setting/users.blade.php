@extends('admin.base')

@section('title')
List Users
@endsection

@section('breadcrumb')
<li><a>Home</a></li>
<li><a>Setting</a></li>
<li><a>Users</a></li>
@endsection

@section('page-content')

@endsection