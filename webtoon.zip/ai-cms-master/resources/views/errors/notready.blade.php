<div class="row">
	<div class="col-md-12">
		<div class="content bg-white text-center">
			<div class="row">
				<div class="col-sm-8 col-sm-offset-2">
					<div class="font-s64 text-gray push-30-t push-50">
						<i class="fa fa-cog fa-spin"></i>
					</div>
					<h1 class="h2 font-w400 push-15 animated fadeInLeftBig">Sorry, this feature will available soon.</h1>
					<h2 class="h3 font-w300 text-dark-op push-50 animated fadeInRightBig">We’ll be back shortly!</h2>
				</div>
			</div>
		</div>
	</div>
</div>
