<ul class="nav-main">
	@foreach ($html as $htm)
	{!! $htm !!}
	@endforeach
</ul>
