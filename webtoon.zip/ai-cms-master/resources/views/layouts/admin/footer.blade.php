<footer id="page-footer" class="content-mini content-mini-full font-s12 bg-gray-lighter clearfix">
	<div class="pull-right">
		Crafted with <i class="fa fa-heart text-city"></i> by <a class="font-w600" target="_blank">nothing628</a>
	</div>
	<div class="pull-left">
		<a class="font-w600" href="http://github.com/" target="_blank">AI-CMS 1.0</a> &copy; <span class="js-year-copy"></span>
	</div>
</footer>