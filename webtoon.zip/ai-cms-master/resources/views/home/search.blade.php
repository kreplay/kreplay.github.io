@extends ('layouts.web.base')

@section('title')
@parent - Advanced Search
@endsection

@section('content')
<div class="content bg-gray-lighter">
	<div class="row items-push">
		<div class="col-sm-7">
			<h1 class="page-heading">
				Search Manga
			</h1>
		</div>
	</div>
</div>
<div class="content"></div>
@endsection
