<template>
	<div class="form-group">
		<slot></slot>
	</div>
</template>

<script>
	export default {
		data() {
			return {};
		},
		props: {}
	}
</script>
