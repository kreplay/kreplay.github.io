<template>
	<h2>{{ msg }}</h2>
</template>

<script type="text/javascript">
	export default {
		data() {
			return {
				msg: "Hello World"
			}
		}
	}
</script>
