<template>
	<div class="block-content">
		<slot></slot>
	</div>
</template>

<script>
	export default {
		data() {
			return {};
		}
	}
</script>
