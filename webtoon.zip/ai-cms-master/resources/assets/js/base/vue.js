window.Vue = require('vue');
