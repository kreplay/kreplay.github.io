<?php 

return [
	'view' => [
		'Admin' => [
			'container' => 'layouts.menu.container',
			'menu'		=> 'layouts.menu.menu',
		],
		'Web' => [
			'container'	=> 'layouts.menu.container',
			'menu'		=> 'layouts.menu.menu',
		]
	]
];
